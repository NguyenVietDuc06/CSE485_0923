@foreach($categories as $category){
    <p>{{$category->name}}</p>
}
@endforeach