<?php
echo "Welcome to Laravel";